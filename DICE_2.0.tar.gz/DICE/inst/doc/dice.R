### R code from vignette source 'dice.Rnw'

###################################################
### code chunk number 1: Make_data_source_table
###################################################
library(DICE)
library(xtable)
myDB = OpenCon()
data_sources = dbReadTable(myDB, "data_sources")
invisible(dbDisconnect(myDB))
# reduce to 4 columns
table_df = data_sources[, c("source_key", "source_abbv", "disease", "source_desc")]
# reduce description to 20 characters
table_df$source_desc = substr(table_df$source_desc, start=1, stop=45)
# remove quidel entry
table_df = table_df[table_df$source_abbv!="quidel", ]
# generate table
print(xtable(table_df, caption=paste0("Complete list of DICE database data-sources as of ", Sys.Date(), "."), label="tab:sources", align="r|r|l|l|l|"), include.rownames=FALSE, include.colnames=TRUE, caption.placement='top')


###################################################
### code chunk number 2: Make_Example1
###################################################
library(DICE)
# Retrieve summary of available data
test = SummaryByCountry()
# This is a list by disease
str(test,1)
# The dengue list entry is a nested list by country
str(test$dengue,1)
# The dengue/brazil entry has four entries
str(test$dengue$brazil,1)
# The total number of regions for dengue/brazil
test$dengue$brazil$tot_regions
# Show how the regions break-out by spatial level
test$dengue$brazil$RegionsByLevel
# A summary of data with weekly cadence
test$dengue$brazil$Weekly
# A summary of data with monthly cadence
test$dengue$brazil$Monthly


###################################################
### code chunk number 3: Make_Example2
###################################################
library(DICE)
# recover the data summary
test = SummaryBySource()
# This is a list by disease
str(test,1)
# The dengue list entry is a nested list by country
str(test$dengue,1)
# The dengue/Thailand entry has only one root location
str(test$dengue$Thailand,1)
# This root location has only one data source (abbreviated 'THA_MH',
# Thailand Ministry of Health)
str(test$dengue$Thailand$Thailand,1)
# Show the data source info
test$dengue$Thailand$Thailand$THA_MH$source_info
# A summary of data by spatial level
test$dengue$Thailand$Thailand$THA_MH$data_summary


###################################################
### code chunk number 4: dice.Rnw:972-979
###################################################
# Open a connection to the DICE database
myDB = OpenCon()
# Downloand the Dengue look-up table
dengue_lut = dbReadTable(conn=myDB, name="dengue_lut")
str(dengue_lut)
# close connection
dbDisconnect(myDB)


###################################################
### code chunk number 5: dice.Rnw:987-993
###################################################
# First see a list of countries
unique(dengue_lut$NAME_2)
# Next generate a list of levels available in Thailand
unique(dengue_lut$level[dengue_lut$NAME_2=="Thailand"])
# Now generate a list of level 4 regions in Thailand
dengue_lut$NAME_4[dengue_lut$level==4 & dengue_lut$NAME_2=="Thailand"]


###################################################
### code chunk number 6: dice.Rnw:1004-1006
###################################################
dengue_lut$NAME_5[dengue_lut$NAME_2=="Thailand" & dengue_lut$NAME_4=="Zone 5"
    & dengue_lut$level==5]


###################################################
### code chunk number 7: dice.Rnw:1016-1018
###################################################
dengue_lut[dengue_lut$NAME_2=="Thailand" & dengue_lut$NAME_4=="Zone 5" &
    dengue_lut$level==4, ]


###################################################
### code chunk number 8: dice.Rnw:1037-1043
###################################################
test_data = get.DICE.data(data_source = "THA_MH", mod_level = 4,
    mod_name=c(NAME_2="Thailand", NAME_3="Central Region", NAME_4="Zone 5"),
    fit_names="all", fit_level = 5, year = 2015, db_opts=
    list(DICE_db="predsci", CDC_server=FALSE), disease="dengue")
# Inspect the output
str(test_data,1)


